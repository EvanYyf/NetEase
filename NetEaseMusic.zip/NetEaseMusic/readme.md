学习写netease.

窗口布局,
音乐播放,
歌单推荐,
音乐搜索.
https://github.com/HuberTRoy/NetEase